<?php
// Incluir las clases necesarias
require_once('../Repositorios/conexion.php'); 
require_once('../Repositorios/repoUsuario.php'); 


// Crear una instancia de repoUsuario
$repoUsuario = new repoUsuario($conn);

// Comprobar que la petición sea POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos JSON de la petición
    $data = json_decode(file_get_contents("php://input"));

    // Comprobar si los datos existen
    if (isset($data->nombre, $data->ubicacion, $data->telefono, $data->contraseña, $data->foto, $data->monedero, $data->carrito, $data->alergenos)) {
        // Crear el usuario
        $idUsuario = $repoUsuario->crearUsuario(
            $data->nombre,
            $data->ubicacion,
            $data->telefono,
            $data->contraseña,
            $data->foto,
            $data->monedero,
            $data->carrito,
            $data->alergenos
        );
        
        // Respuesta exitosa con el id del usuario
        echo json_encode(['idUsuario' => $idUsuario, 'message' => 'Usuario creado exitosamente']);
    } else {
        // Respuesta con error si faltan parámetros
        echo json_encode(['error' => 'Datos incompletos']);
    }
} else {
    echo json_encode(['error' => 'Método no permitido']);
}
?>
