<?php
require_once 'conexion.php';
require_once '../Clases/Usuario.php';
require_once '../Clases/Alergenos.php';

class RepoUsuario {
    private $conexion;

    // Constructor que recibe la conexión
    public function __construct($db) {
        $this->conexion = $db->getConnection();  // Obtener la conexión de DB
    }

    // Crear un nuevo usuario
    public function crearUsuario($nombre, $ubicacion, $telefono, $contraseña, $foto, $monedero, $carrito, $alergenos) {
        // Preparar la consulta SQL para insertar un nuevo usuario
        $sql = "INSERT INTO Usuario (nombre, ubicacion, telefono, contraseña, foto, monedero, carrito) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        if ($stmt = $this->conexion->prepare($sql)) {
            // Convertir el carrito a JSON
            $carrito_json = json_encode($carrito);
            
            // Ejecutar la consulta
            $stmt->bind_param("sssssis", $nombre, $ubicacion, $telefono, $contraseña, $foto, $monedero, $carrito_json);
            $stmt->execute();

            // Obtener el ID del usuario recién insertado
            $idUsuario = $this->conexion->insert_id;

            // Asociar los alérgenos con el usuario
            $this->asociarAlergenos($idUsuario, $alergenos);

            return $idUsuario;  // Retornar el ID del nuevo usuario
        } else {
            die("Error en la consulta: " . $this->conexion->error);
        }
    }

    // Función para asociar los alérgenos al usuario
    private function asociarAlergenos($idUsuario, $alergenos) {
        $sql = "INSERT INTO Usuario_has_Alergenos (Usuario_idUsuario, Alergenos_idAlergenos) 
                VALUES (?, ?)";
        
        if ($stmt = $this->conexion->prepare($sql)) {
            foreach ($alergenos as $idAlergeno) {
                // Asociar cada alérgeno con el usuario
                $stmt->bind_param("ii", $idUsuario, $idAlergeno);
                $stmt->execute();
            }
        } else {
            die("Error en la consulta: " . $this->conexion->error);
        }
    }

}
